<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

chdir('..');
include_once 'services/ClasseService.php';
extract($_POST);

$fs = new ClasseService();

header('Content-type: application/json');
echo json_encode($fs->count());