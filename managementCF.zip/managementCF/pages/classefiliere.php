<?php
if (session_status() != PHP_SESSION_ACTIVE) {
    session_start();
}

if (isset($_SESSION['employe'])) {
    ?>  

    <form >
        <div class="container-fluid">
            <div class="card bg-white" >
                <div class="card-header card-color" style="background-color: #f9ecec">
                    <p class="h2 text-center text-uppercase font-weight-bold pt-2">Les classes de chaque Filiere</p>
                </div>
                <div class="card-body container-fluid" >
                    <div class="row">
                        <div class="col-sm-6 mb-2">
                            <label for='filiere'>Veuillez choisir la filière </label>
                            

                            <select class="form-control" id="codefiliere1" required>
                                
                                <option value="Tous" name="Tous" id="Tous" selected>Tous</option>
                                <?php
                                include_once 'beans/Filiere.php';
                                include_once 'services/FiliereService.php';

                                $var1 = new FiliereService();

                                foreach ($var1->findEverything() as $filiere) {
                                    ?>
                                    <option value="<?php echo $filiere->getId() ?>" name="<?php echo $filiere->getAbr() ?>"><?php echo $filiere->getAbr() ?></option>

                                <?php } ?>
                            </select>
                             
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <button type="button" class="btn btn-outline-success mt-3 mb-3" id="submit">Chercher</button>
                        </div>
                    </div>
                    <div class="row table-responsive m-auto rounded">
                        <table class="table">
                            <thead>
                                <tr class="text-uppercase bg-light">
                                    <th scope="col">Id</th>
                                    <th scope="col">Code</th>
                                    <th scope="col">nom</th>
                                    <th scope="col">Filière</th>
                                </tr>
                            </thead>

                            <tbody id="haha">



                            </tbody>


                        </table>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <script src="script/historique.js" type="text/javascript"></script>
    <?php
} else {
    header("Location: ../index.php");
}
?>
