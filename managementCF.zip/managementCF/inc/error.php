<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<html>
    <head>
        <title>Error - Page invalide</title>
    </head>
    <body style="
            width: 100%;height: 100%;text-align: center;margin-top: 25%;
          ">
        <h1>Error - Page invalide</h1>
    </body>
</html>